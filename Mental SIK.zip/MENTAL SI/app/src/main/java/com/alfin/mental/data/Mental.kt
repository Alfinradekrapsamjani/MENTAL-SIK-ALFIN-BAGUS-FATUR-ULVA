package com.alfin.mental.data

data class Mental(
    var name:String = "",
    var latinName:String = "",
    var detail:String = "",
    var photo:Int = 0
)
