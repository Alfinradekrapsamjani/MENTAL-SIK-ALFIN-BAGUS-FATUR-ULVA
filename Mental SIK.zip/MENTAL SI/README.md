# Mental

Membuat aplikasi list mental dengan menggunakan fitur :

1. Recycleview
2. CardView
3. Intent with data
4. Intent

Nama Anggota Kelompok :

Alfin Radek R
Ahmad Kubagus Subhki
M.Cholik Faturrohman
Ulva Widowati
